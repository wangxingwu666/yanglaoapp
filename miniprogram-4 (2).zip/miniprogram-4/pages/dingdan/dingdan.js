import Dialog from '@vant/weapp/dialog/dialog';
import Toast from '@vant/weapp/toast/toast';
Page({
  data: {
    list0:[
      {quan:true,dizhi:"江苏科技大学",lxr:"江小科" ,sjh:"15301520322"},
      {quan:false,dizhi:"镇江高等职业学院",lxr:"江小科",sjh:"15301520322"},
      {quan:false,dizhi:"江苏大学京江校区",lxr:"江小科",sjh:"15301520322"}
    ],
    show3:false,
    show: false,
    show1: false,
    show2: false,
    show4: false,
    show5: false,
    show6:false,
    show7:false,
    idx:0,
    selectedAddress: "请填写服务地址",
    selectedTime: "选择上门时间",
    currentDate: new Date().getTime(),
    minDate: new Date().getTime(),
  },
  filter(type, options) {
    if (type === 'minute') {
      return options.filter((option) => option % 5 === 0);
    }
    return options;
  },
  formatTime(timestamp) {
    // 自定义时间格式化方法
    // 可根据需要自定义时间格式
    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hour = date.getHours().toString().padStart(2, '0');
    const minute = date.getMinutes().toString().padStart(2, '0');
    return `${year}-${month}-${day} ${hour}:${minute}`;
  },
  formatter(type, value) {
    if (type === 'year') {
      return `${value}年`;
    } else if (type === 'month') {
      return `${value}月`;
    } else if (type === 'day') {
      return `${value}日`;
    } else if (type === 'hour') {
      return `${value}时`;
    } else if (type === 'minute') {
      return `${value}分`;
    }
    return value;
  },
  showPopup() {
    this.setData({ show: true });
  },
  showPopup1() {
    this.setData({ show1: true });
  },
  showPopup2() {
    this.setData({ show2: true });
  },
 
  showPopup5() {
    this.setData({ show5: true });
  },
  showPopup6() {
    this.setData({ show6: true });
  },
  showPopup4(e) {
    this.setData({ show4: true });
    console.log(e);
    let {index} = e.currentTarget.dataset;
    let arr = this.data.list0;
    wx.showModal({
      title: '确定要删除该地址吗',
      confirmColor:"#5DC1BF",
      success: (res) => {
        if (res.confirm) {
          arr.splice(index,1);    
          this.setData({
            list0:arr,
            show7:true
          });
          setTimeout(() => {
            this.setData({
              show7: false
            });
          }, 2000);
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  onClose() {
    this.setData({ 
      show: false,
    });
  },
  onClose1() {
    this.setData({ 
      show1: false,
    });
  },
  onClose2() {
    this.setData({ show2: false });
  },
  onClose3(e) {
    this.setData({ 
      show3: false,
    });
  },
  onClose4() {
    this.setData({ show4: false });
  },
  onClose5() {
    this.setData({ show5: false });
  },
  onClose6() {
    this.setData({ show6: false });
  },
  onChange(event) {
    const { picker, value, index } = event.detail;
    picker.setColumnValues(1, citys[value[0]]);
  },
  onInput(event) {
    this.setData({
      currentDate: event.detail,
      selectedTime: this.formatTime(event.detail)
    });
  },
  showPopup3(e) {
    console.log(e);
    this.setData({ 
      show3: true,
      searchinput:''
    });
  },
  Change1(e){
    console.log(e.detail.value);
    var value  = e.detail.value;
    var  idx  = this.data.idx;
    let list = this.data.list0.map((item, index) => {
      if (index === idx) {
        return { ...item, dizhi: value};
        }else {
          return item;
        }
    });
    this.setData({
      list0: list,
    });
  },
  Change2(e){
    console.log(e.detail.value);
    var value  = e.detail.value;
    var  idx  = this.data.idx;
    let list = this.data.list0.map((item, index) => {
      if (index === idx) {
        return { ...item, lxr: value};
        }else {
          return item;
        }
    });
    this.setData({
      list0: list,
    });
  },
  Change3(e){
    console.log(e.detail.value);
    var value  = e.detail.value;
    var  idx  = this.data.idx;
    let list = this.data.list0.map((item, index) => {
      if (index === idx) {
        return { ...item, sjh: value};
        }else {
          return item;
        }
    });
    this.setData({
      list0: list,
    });
  },
  tap(e){
    console.log(e.currentTarget.dataset.index);
    var thisIdx = e.currentTarget.dataset.index;
    let list = this.data.list0.map((item, index) => {
      if (index === thisIdx) {
        return { ...item, quan: !item.quan };
      } else {
        return { ...item, quan: false };
      }
    });
    this.setData({
      list0: list,
      selectedAddress: list[thisIdx].dizhi,
      idx:thisIdx
    });
  },
  getUserInfo(event) {
    console.log(event.detail);
  },
  ontap() {
    this.setData({ show6: true });
  },
  onClickHide() {
    this.setData({ show6: false });
  },
  onClickHide1() {
    this.setData({ show7: false });
  },
  
});