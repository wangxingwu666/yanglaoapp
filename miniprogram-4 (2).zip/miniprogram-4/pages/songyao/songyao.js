Page({

  data: {
    listArr:[{name:"速效救心丸"},
            {name:"硝酸甘油"}
          ],
    listArr2:[{name:"硝苯地平"},
            {name:"卡托普利"},
            {name:"缓释片"},
            {name:"控释片"}
          ],
    listArr3:[{name:"莲花清瘟胶囊"},
            {name:"黄芩口服液"},
            {name:"维C银翘片"}
          ],
    listArr4:[{name:"布洛芬"},
            {name:"散利痛"}
          ],
    listArr5:[{name:"左氧氟沙星"},
            {name:"吡哌酸"}, 
          ],
    on1:false,
    on2:true,
    on3:true,
    on4:true,
    on5:true,
    back1:false,
    back2:true,
    back3:true,
    back4:true,
    back5:true
    },
    a(){
      this.setData({
        on1:!this.data.on1,
        on2:true,
        on3:true,
        on4:true,
        on5:true,
        back1:!this.data.back1,
        back2:true,
        back3:true,
        back4:true,
        back5:true
      })
    },
    b(){
      this.setData({
        on2:!this.data.on2,
        on1:true,
        on3:true,
        on4:true,
        on5:true,
        back2:!this.data.back2,
        back1:true,
        back3:true,
        back4:true,
        back5:true
      })
    },
    c(){
      this.setData({
        on3:!this.data.on3,
        on2:true,
        on1:true,
        on4:true,
        on5:true,
        back3:!this.data.back3,
        back2:true,
        back1:true,
        back4:true,
        back5:true
      })
    },
    d(){
      this.setData({
        on4:!this.data.on4,
        on2:true,
        on3:true,
        on1:true,
        on5:true,
        back4:!this.data.back4,
        back2:true,
        back3:true,
        back1:true,
        back5:true
      })
    },
    e(){
      this.setData({
        on5:!this.data.on5,
        on2:true,
        on3:true,
        on4:true,
        on1:true,
        back5:!this.data.back5,
        back2:true,
        back3:true,
        back4:true,
        back1:true
      })
    },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
});