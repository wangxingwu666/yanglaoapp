Page({

  /**
   * 页面的初始数据
   */
  data: {
    isGray:false,
    isWhite:false 
  },

  setBackgroundColor(e) {
    console.log(e);     
      this.setData({
        isGray: !this.data.isGray
      });
  },
  setColor(e){
    console.log(e);
    this.setData({
      isWhite: !this.data.isWhite
    });
  },
});