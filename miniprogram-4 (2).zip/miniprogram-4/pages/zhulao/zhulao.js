Page({

  data: {
    listArr:[{name:"家电维修"},
            {name:"开锁修锁"},
            {name:"管道疏通"},
            {name:"水电维修"}
          ],
    listArr2:[{name:"洗头"},
            {name:"面部清洁"},
            {name:"手足清洁"},
            {name:"上门理发"},
            {name:"居室清洁"},
            {name:"衣物洗涤"},
            {name:"物品整理"},
            {name:"玻璃清洁"}
          ],
    listArr3:[{name:"代购菜品"},
            {name:"代购米面"}
          ],
    listArr4:[{name:"家庭诊疗"},
            {name:"赔医就诊"},
            {name:"康复护理"},
            {name:"上门药品"},
            {name:"健康教育"}
          ],
    listArr5:[{name:"辅助洗浴"}
          ],
    listArr6:[{name:"陪同购物"},
            {name:"陪同散步"},
            {name:"物品代购"}
          ],
    listArr7:[{name:"读书读报"},
            {name:"陪同聊天"},
            {name:"亲情关怀"},
            {name:"亲属沟通"}
          ],
    on1:false,
    on2:true,
    on3:true,
    on4:true,
    on5:true,
    on6:true,
    on7:true,
    back1:false,
    back2:true,
    back3:true,
    back4:true,
    back5:true,
    back6:true,
    back7:true
    },
    a(){
      this.setData({
        on1:!this.data.on1,
        on2:true,
        on3:true,
        on4:true,
        on5:true,
        on6:true,
        on7:true,
        back1:!this.data.back1,
        back2:true,
        back3:true,
        back4:true,
        back5:true,
        back6:true,
        back7:true
      })
    },
    b(){
      this.setData({
        on2:!this.data.on2,
        on1:true,
        on3:true,
        on4:true,
        on5:true,
        on6:true,
        on7:true,
        back2:!this.data.back2,
        back1:true,
        back3:true,
        back4:true,
        back5:true,
        back6:true,
        back7:true
      })
    },
    c(){
      this.setData({
        on3:!this.data.on3,
        on2:true,
        on1:true,
        on4:true,
        on5:true,
        on6:true,
        on7:true,
        back3:!this.data.back3,
        back2:true,
        back1:true,
        back4:true,
        back5:true,
        back6:true,
        back7:true
      })
    },
    d(){
      this.setData({
        on4:!this.data.on4,
        on2:true,
        on3:true,
        on1:true,
        on5:true,
        on6:true,
        on7:true,
        back4:!this.data.back4,
        back2:true,
        back3:true,
        back1:true,
        back5:true,
        back6:true,
        back7:true
      })
    },
    e(){
      this.setData({
        on5:!this.data.on5,
        on2:true,
        on3:true,
        on4:true,
        on1:true,
        on6:true,
        on7:true,
        back5:!this.data.back5,
        back2:true,
        back3:true,
        back4:true,
        back1:true,
        back6:true,
        back7:true
      })
    },
    f(){
      this.setData({
        on6:!this.data.on6,
        on2:true,
        on3:true,
        on4:true,
        on1:true,
        on5:true,
        on7:true,
        back6:!this.data.back6,
        back2:true,
        back3:true,
        back4:true,
        back1:true,
        back5:true,
        back7:true
      })
    },
    g(){
      this.setData({
        on7:!this.data.on7,
        on2:true,
        on3:true,
        on4:true,
        on1:true,
        on5:true,
        on6:true,
        back7:!this.data.back7,
        back2:true,
        back3:true,
        back4:true,
        back1:true,
        back5:true,
        back6:true
      })
    },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
});