// pages/match/match.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    color:false,
    color02:false,
    color03:false,
    color04:false,
    color05:false,
    color06:false,
    color07:false,
    color08:false,
    color09:false
  },
  hover(){
    this.setData({
      color:!this.data.color
    })
  },
  hover02(){
    this.setData({
      color02:!this.data.color02
    })
  },
  hover03(){
    this.setData({
      color03:!this.data.color03
    })
  },
  hover04(){
    this.setData({
      color04:!this.data.color04
    })
  },
  hover05(){
    this.setData({
      color05:!this.data.color05
    })
  },
  hover06(){
    this.setData({
      color06:!this.data.color06
    })
  },
  hover07(){
    this.setData({
      color07:!this.data.color07
    })
  },
  hover08(){
    this.setData({
      color08:!this.data.color08
    })
  },
  hover09(){
    this.setData({
      color09:!this.data.color09
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
});