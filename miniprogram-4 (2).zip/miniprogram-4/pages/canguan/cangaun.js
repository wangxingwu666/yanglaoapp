Page({
  data: {
    tp:true,
    sp:false,
    value:3,
    active: 0,
    show: false,
    show1:false,
    show2:false,
  },
  back(){
    wx.navigateBack({
      delta: 1
    })
  },
  onInput(event) {
    this.setData({
      currentDate: event.detail,
      selectedTime1: this.formatTime(event.detail)
    });
  },
  onInput2(event) {
    this.setData({
      currentDate2: event.detail,
      selectedTime2: this.formatTime(event.detail)
    });
  },
  showPopup() {
    this.setData({ show: true });
  },
  showPopup1() {
    this.setData({ show1: true });
  },
  showPopup3() {
    this.setData({ show2: true });
  },

  onClose() {
    this.setData({ show: false });
  },
  onClose1() {
    this.setData({ show1: false });
  },
  onClose2() {
    this.setData({ show2: false });
  },
    tap1(){
      this.setData({
        tp:true,
        sp:false
      })
    },
    tap2(){
      this.setData({
        tp:false,
        sp:true
      })
    },
    dh(){
      wx.showModal({
        title:'是否要拨打电话',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    },
    dt(){
      wx.showModal({
        title:'是否要打开地图',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    },
});