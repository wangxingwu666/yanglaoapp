// pages/jigou/jigou.js
Page({

  data: {
    tp:true,
    sp:false,
    value:3,
    active: 0,
    show: false,
    show0: false,
    show1:false,
    show2:false,
    show4:false,
    value0:5,
    value:"点击选择",
    selectedTime1:"",
    selectedTime2:"",
    currentDate: new Date().getTime(),
    minDate: new Date().getTime(),
    currentDate2: new Date().getTime(),
    minDate2: new Date().getTime(),
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    columns: ['本人', '子女', '亲属', '亲戚', '其他'],
  },
  onChange0(event) {
    this.setData({
      value:event.detail.value
    })
  },
  formatTime(timestamp) {
    // 自定义时间格式化方法
    // 可根据需要自定义时间格式
    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  },
  formatter(type, value) {
    if (type === 'year') {
      return `${value}年`;
    } else if (type === 'month') {
      return `${value}月`;
    } else if (type === 'day') {
      return `${value}日`;
    } 
    return value;
  },
  onInput(event) {
    this.setData({
      currentDate: event.detail,
      selectedTime1: this.formatTime(event.detail)
    });
  },
  onInput2(event) {
    this.setData({
      currentDate2: event.detail,
      selectedTime2: this.formatTime(event.detail)
    });
  },
  showPopup0() {
    this.setData({ show0: true });
  },
  showPopup() {
    this.setData({ show: true });
  },
  showPopup1() {
    this.setData({ show1: true });
  },
  showPopup3() {
    this.setData({ show2: true });
  },
  showPopup4() {
    this.setData({ show4: true });
  },
  onClose() {
    this.setData({ show: false });
  },
  onClose1() {
    this.setData({ show1: false });
  },
  onClose2() {
    this.setData({ show2: false });
  },
  onClose4() {
    this.setData({ 
      show4: false,
      show: false
    });
  },
  onClose0() {
    this.setData({ show0: false });
  },
    tap1(){
      this.setData({
        tp:true,
        sp:false
      })
    },
    tap2(){
      this.setData({
        tp:false,
        sp:true
      })
    },
    dh(){
      wx.showModal({
        title:'是否要拨打电话',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    },
    dt(){
      wx.showModal({
        title:'是否要打开地图',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    },
});