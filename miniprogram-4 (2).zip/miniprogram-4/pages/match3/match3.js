Page({
  data: {
   close:true,
   close2:true,
   close3:true,
   close4:true,
   back:true,
   back1:true,
   back2:true,
   back3:true,
   back01:true,
   back02:true,
   back03:true,
   back04:true,
   back05:true,
   back06:true,
   back07:true,
   back08:true,
   back09:true
  },
  tap1(){
    this.setData({
      close:!this.data.close,
      back:!this.data.back,
      close2:true,
      back1:true,
      close3:true,
      back2:true,
      close4:true,
      back3:true
    })
  },
  tap2(){
    this.setData({
      close2:!this.data.close2,
      back1:!this.data.back1,
      close:true,
      back:true,
      close3:true,
      back2:true,
      close4:true,
      back3:true
    })
  },
  tap3(){
    this.setData({
      close3:!this.data.close3,
      back2:!this.data.back2,
      close2:true,
      back1:true,
      close:true,
      back:true,
      close4:true,
      back3:true
    })
  },
  tap4(){
    this.setData({
      close4:!this.data.close4,
      back3:!this.data.back3,
      close2:true,
      back1:true,
      close3:true,
      back2:true,
      close:true,
      back:true
    })
  },
  i(e){
    console.log(e);
    this.setData({
      back01:!this.data.back01,
      back02:!this.data.back01,
      back03:true,
      back04:true,
      back05:true,
      back06:true,
      back07:true,
      back08:true,
      back09:true,
      
    })
  }, 
   a(e){
    console.log(e);
    this.setData({
      back02:!this.data.back02,
      back01:!this.data.back02,
      back03:true,
      back04:true,
      back05:true,
      back06:true,
      back07:true,
      back08:true,
      back09:true,
     
    })
  }, 
  b(e){
    console.log(e);
    this.setData({
      back03:!this.data.back03,
      back01:!this.data.back03,
      back02:true,
      back04:true,
      back05:true,
      back06:true,
      back07:true,
      back08:true,
      back09:true,
      
    })
  }, 
  c(e){
    console.log(e);
    this.setData({
      back04:!this.data.back04,
      back01:!this.data.back04,
      back02:true,
      back03:true,
      back05:true,
      back06:true,
      back07:true,
      back08:true,
      back09:true,
      
    })
  }, 
  d(e){
    console.log(e);
    this.setData({
      back05:!this.data.back05,
      back01:!this.data.back05,
      back02:true,
      back03:true,
      back04:true,
      back06:true,
      back07:true,
      back08:true,
      back09:true,
      
    })
  }, 
  e(e){
    console.log(e);
    this.setData({
      back06:!this.data.back06,
      back01:!this.data.back06,
      back02:true,
      back03:true,
      back05:true,
      back04:true,
      back07:true,
      back08:true,
      back09:true,
      
    })
  }, 
  f(e){
    console.log(e);
    this.setData({
      back07:!this.data.back07,
      back01:!this.data.back04,
      back02:true,
      back03:true,
      back05:true,
      back06:true,
      back04:true,
      back08:true,
      back09:true,
     
    })
  }, 
  g(e){
    console.log(e);
    this.setData({
      back08:!this.data.back08,
      back01:!this.data.back08,
      back02:true,
      back03:true,
      back05:true,
      back06:true,
      back07:true,
      back04:true,
      back09:true,
      
    })
  }, 
  h(e){
    console.log(e);
    this.setData({
      back09:!this.data.back09,
      back01:!this.data.back09,
      back02:true,
      back03:true,
      back05:true,
      back06:true,
      back07:true,
      back08:true,
      back04:true,
    });
  }, 
  qd(){
    this.setData({
      back:true,
      back1:true,
      back2:true,
      back3:true,
      close:true,
      close2:true,
      close3:true,
      close4:true
    })
  },
  cz(){
    this.setData({
      back01:true,
      back02:true,
      back03:true,
      back04:true,
      back05:true,
      back06:true,
      back07:true,
      back08:true,
      back09:true
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
});